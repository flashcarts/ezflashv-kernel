/*********************************************************
Date: 2005 09 21 15:40  
*********************************************************/
#define ARM9  1
#define MAIN_GLOBALS 1

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h> 
#include <ctype.h>
#include <setjmp.h>

//SD dir control bit cmddir=bit0 clken=bit1
//output
#define SDDIR			(*(volatile u16*)0x8800000)
//SD send get control bit send=bit0 get=bit1
//output
#define SDCON			(*(volatile u16*)0x9800000)
//SD output data obyte[7:0]=AD[7:0]
//output
#define SDODA			(*(volatile u16*)0x9000000)
//SD input data AD[7:0]=ibyte[7:0]
//input
#define SDIDA			(*(volatile u16*)0x9000000)
//readsector data1
#define SDIDA1			(*(volatile u16*)0x9200000)
//readsector data2
#define SDIDA2			(*(volatile u16*)0x9400000)
//readsector data3
#define SDIDA3			(*(volatile u16*)0x9600000)
//SD stutas cmdneg=bit0 cmdpos=bit1 issend=bit2 isget=bit3
//input
#define SDSTA			(*(volatile u16*)0x9800000)

//======================================================
void readsector(u32 sectorn,u32 TAddr)
{
	u32 i;
	
	SDCON=0x8;
	SDIDA1=0x40+17;
	SDIDA2=(sectorn>>7);
	SDIDA3=(sectorn<<9);
	SDDIR=0x29;
	while ((SDSTA&0x01) != 0x01) ;
	SDDIR=0x09;
	
	SDDIR=0x49;
	while ((SDSTA&0x40) != 0x40);
	SDDIR=0x09;
		
	SDDIR=0x8;//cmd input clken=0 datadir input clock=0
	SDCON=0x4;//send=0 get=0 en25=1 cmd1=0

	i = SDDIR;
	for(i=0;i<0x100;i++)
	{
		*(u16*)(TAddr+i*2) = *(volatile u16*)0x8800000;
	}
} 
//==================================================

