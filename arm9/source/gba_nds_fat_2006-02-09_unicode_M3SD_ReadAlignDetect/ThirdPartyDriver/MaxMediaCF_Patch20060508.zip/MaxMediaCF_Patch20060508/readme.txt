v1.0
Please chek out www.codejunkies.com for future updates.
